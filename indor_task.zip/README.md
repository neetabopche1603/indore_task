1. Download This Project.
2. Install Composer.
3. Open terminal and type composer update or composer upgrade.
4. copy .env.example and rename .env
5. Generate App Key php artisan key:generate
6. Create Database and name change .env file.
7. open terminal and type php artisan migrate.
8. Then run the project and register new user.
9. Then Login user.